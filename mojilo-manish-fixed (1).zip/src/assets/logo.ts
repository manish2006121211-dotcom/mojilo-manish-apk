import appIconPath from './images/app_icon_1786271094033.jpg';

export const MOJILO_MANISH_LOGO = appIconPath;
export const APP_PACKAGE_ID = 'com.mojilomanish.app';
export const APP_NAME = 'Mojilo Manish';
