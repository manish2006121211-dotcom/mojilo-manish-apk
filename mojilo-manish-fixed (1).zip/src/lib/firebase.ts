import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  setPersistence,
  browserLocalPersistence,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  query,
  where,
  addDoc,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
} from 'firebase/storage';

// Firebase configuration for the Mojilo Manish web app.
// These values come from Firebase Console > Project settings > Your apps.
const firebaseConfig = {
  apiKey: 'AIzaSyDnrBKTl9XOHaVBQOPUpoO_YnCnlSW8SM0',
  authDomain: 'mojilo-manish.firebaseapp.com',
  projectId: 'mojilo-manish',
  storageBucket: 'mojilo-manish.firebasestorage.app',
  messagingSenderId: '245156353643',
  appId: '1:245156353643:web:1a0cc66bb574915b10832e',
  measurementId: 'G-7F3Y8JX789',
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);

// Keep users signed in on supported web/Capacitor environments.
setPersistence(auth, browserLocalPersistence).catch(() => {});

export const db = getFirestore(app);
export const storage = getStorage(app);

export {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  query,
  where,
  addDoc,
  deleteDoc,
  onSnapshot,
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
};
