import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  onAuthStateChanged 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  getDocs, 
  query, 
  where 
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
  selectedGroupId: string;
  setSelectedGroupId: (id: string) => void;
  login: (email: string, pass: string) => Promise<void>;
  signup: (email: string, pass: string, name: string, groupIds?: string[]) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
  bootstrapFirstAdmin: () => Promise<{ success: boolean; message: string }>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string>('all');

  // Fetch or create user profile in Firestore
  const fetchProfile = async (uid: string, authUserEmail?: string): Promise<UserProfile | null> => {
    try {
      const userRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const data = userSnap.data() as UserProfile;
        setUserProfile(data);
        return data;
      } else {
        // First profile initialization if document doesn't exist
        // Check if there are ANY users in Firestore yet. If none, auto-grant Admin role to first user.
        let assignedRole: UserRole = 'user';
        try {
          const usersSnap = await getDocs(collection(db, 'users'));
          if (usersSnap.empty) {
            assignedRole = 'admin';
          }
        } catch {
          // If security rules prevent reading all users or error occurs, default to user
        }

        const newProfile: UserProfile = {
          userId: uid,
          name: authUserEmail ? authUserEmail.split('@')[0] : 'Student User',
          email: authUserEmail || '',
          role: assignedRole,
          groupIds: [],
          status: 'active',
          createdAt: new Date().toISOString(),
        };

        await setDoc(userRef, newProfile);
        setUserProfile(newProfile);
        return newProfile;
      }
    } catch (err: any) {
      console.error('Error fetching/creating user profile:', err);
      setError(err.message || 'Failed to load user profile');
      return null;
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      setUser(authUser);
      if (authUser) {
        await fetchProfile(authUser.uid, authUser.email || undefined);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      const res = await signInWithEmailAndPassword(auth, email.trim(), pass);
      await fetchProfile(res.user.uid, res.user.email || undefined);
    } catch (err: any) {
      console.error('Login error:', err);
      let msg = 'Failed to sign in. Please check your email and password.';
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        msg = 'Invalid email or password.';
      } else if (err.code === 'auth/user-not-found') {
        msg = 'No user account found with this email.';
      } else if (err.code === 'auth/too-many-requests') {
        msg = 'Too many failed login attempts. Please try again later.';
      }
      setError(msg);
      throw new Error(msg);
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, pass: string, name: string, groupIds: string[] = []) => {
    setError(null);
    setLoading(true);
    try {
      const res = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      
      // Determine if this is the very first user in the database
      let role: UserRole = 'user';
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        if (usersSnap.empty) {
          role = 'admin';
        }
      } catch {
        // Fallback
      }

      const newProfile: UserProfile = {
        userId: res.user.uid,
        name: name.trim() || email.split('@')[0],
        email: email.trim(),
        role: role,
        groupIds: groupIds,
        status: 'active',
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'users', res.user.uid), newProfile);
      setUserProfile(newProfile);
    } catch (err: any) {
      console.error('Signup error:', err);
      let msg = err.message || 'Failed to create account.';
      if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please login instead.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      }
      setError(msg);
      throw new Error(msg);
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setUserProfile(null);
      setSelectedGroupId('all');
    } catch (err: any) {
      console.error('Logout error:', err);
      setError('Failed to log out.');
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err: any) {
      console.error('Password reset error:', err);
      let msg = err.message || 'Failed to send password reset email.';
      if (err.code === 'auth/user-not-found') {
        msg = 'No user account found with this email.';
      }
      setError(msg);
      throw new Error(msg);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.uid, user.email || undefined);
    }
  };

  const bootstrapFirstAdmin = async (): Promise<{ success: boolean; message: string }> => {
    if (!user) {
      return { success: false, message: 'You must be signed in first.' };
    }
    try {
      // Check if any admin exists
      const q = query(collection(db, 'users'), where('role', '==', 'admin'));
      const adminSnap = await getDocs(q);

      if (!adminSnap.empty) {
        return { 
          success: false, 
          message: 'An Admin account already exists in the system. Use Admin credentials or contact existing Admin.' 
        };
      }

      // Claim Admin status
      const userRef = doc(db, 'users', user.uid);
      const updatedProfile: UserProfile = {
        ...(userProfile || {
          userId: user.uid,
          name: user.email ? user.email.split('@')[0] : 'Admin User',
          email: user.email || '',
          groupIds: [],
          status: 'active',
          createdAt: new Date().toISOString(),
        }),
        role: 'admin'
      };

      await setDoc(userRef, updatedProfile, { merge: true });
      setUserProfile(updatedProfile);

      return { 
        success: true, 
        message: 'Congratulations! You are now set as the First Administrator of Mojilo Manish.' 
      };
    } catch (err: any) {
      console.error('Bootstrap admin error:', err);
      return { success: false, message: err.message || 'Failed to claim First Admin status.' };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        error,
        selectedGroupId,
        setSelectedGroupId,
        login,
        signup,
        logout,
        resetPassword,
        refreshProfile,
        bootstrapFirstAdmin,
        clearError: () => setError(null),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
